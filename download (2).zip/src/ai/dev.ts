import { config } from 'dotenv';
config();

import '@/ai/flows/auto-background-fill.ts';
import '@/ai/flows/detect-layout-structure.ts';


import { useState, useRef, useCallback, useEffect } from "react";
import type { fabric } from "fabric";

// The properties we want to save for each canvas state
const HISTORY_PROPS = [
  "selectable",
  "evented",
  "data",
  "visible",
  "hasControls",
  'isCropGroup',
  'isPlaceholder',
  'name',
];

export function useCanvasHistory(canvas: fabric.Canvas | null) {
  const isRestoringHistory = useRef(false);
  const historyStack = useRef<string[]>([]);
  const historyIndex = useRef(-1);

  // Ref to hold the debounce timer
  const debounceTimer = useRef<NodeJS.Timeout | null>(null);

  // useState is what triggers React to re-render the UI
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  // Centralized function to update the button states.
  // Calling setCanUndo/setCanRedo is what tells React to check if the buttons
  // need to be re-rendered.
  const updateUndoRedoState = useCallback(() => {
    setCanUndo(historyIndex.current > 0);
    setCanRedo(historyIndex.current < historyStack.current.length - 1);
  }, []);

  /**
   * Saves the current canvas state to the history stack after a delay.
   * This prevents saving excessive states during rapid modifications.
   */
  const updateHistory = useCallback(() => {
    if (!canvas || isRestoringHistory.current || (canvas as any).isDisposed) return;

    // Clear any existing timer to reset the debounce period
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    // Set a new timer. The history will only be saved after 250ms of inactivity.
    debounceTimer.current = setTimeout(() => {
      const currentState = JSON.stringify(canvas.toJSON(HISTORY_PROPS));
      
      // If we are undoing, we need to slice the history stack
      if (historyIndex.current < historyStack.current.length - 1) {
        historyStack.current.splice(historyIndex.current + 1);
      }

      // Do not save if the state is the same as the last one
      if (historyStack.current[historyIndex.current] === currentState) {
        return;
      }

      historyStack.current.push(currentState);
      historyIndex.current++;
      
      // Update the button states AFTER the history has been modified
      updateUndoRedoState();
    }, 250);
  }, [canvas, updateUndoRedoState]);

  const restoreHistory = useCallback((index: number) => {
      if (!canvas || (canvas as any).isDisposed) return;
      isRestoringHistory.current = true;
      const stateToRestore = historyStack.current[index];
      
      canvas.loadFromJSON(stateToRestore, () => {
        if ((canvas as any).isDisposed) {
          isRestoringHistory.current = false;
          return;
        }
        canvas.renderAll();
        isRestoringHistory.current = false;
        
        // This is important to re-sync the active object state with the UI
        const activeObject = canvas.getActiveObject();
        if (activeObject) {
            canvas.fire('selection:updated', { target: activeObject });
        } else {
            canvas.fire('selection:cleared');
        }
      });
    }, [canvas]
  );

  const handleUndo = useCallback(() => {
    if (canUndo) {
      // Clear any pending history save before undoing
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
      
      historyIndex.current--;
      restoreHistory(historyIndex.current);
      // Explicitly update state to trigger re-render
      updateUndoRedoState();
    }
  }, [canUndo, restoreHistory, updateUndoRedoState]);

  const handleRedo = useCallback(() => {
    if (canRedo) {
      // Clear any pending history save before redoing
      if (debounceTimer.current) clearTimeout(debounceTimer.current);

      historyIndex.current++;
      restoreHistory(historyIndex.current);
      // Explicitly update state to trigger re-render
      updateUndoRedoState();
    }
  }, [canRedo, restoreHistory, updateUndoRedoState]);
  
  // This effect is responsible for saving the very first state of the canvas.
  useEffect(() => {
    // A small delay to ensure canvas is fully ready before the first save
    const initialSaveTimeout = setTimeout(() => {
        if (canvas && historyStack.current.length === 0) {
            updateHistory();
        }
    }, 300); // Increased delay to ensure everything is settled

    return () => clearTimeout(initialSaveTimeout);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canvas]);

  return {
    updateHistory,
    handleUndo,
    handleRedo,
    canUndo,
    canRedo,
    isRestoringHistory,
  };
};

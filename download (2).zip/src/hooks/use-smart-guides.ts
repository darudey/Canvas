
"use client";

import { useCallback, useEffect } from 'react';
import { fabric } from 'fabric';

const SNAPPING_THRESHOLD = 8;

export function useSmartGuides(canvas: fabric.Canvas | null) {
  let guideLines: fabric.Line[] = [];

  const clearGuides = useCallback(() => {
    if (!canvas || !guideLines.length) return;
    guideLines.forEach(line => canvas.remove(line));
    guideLines = []; // Clear the internal array
    canvas.renderAll();
  }, [canvas]);

  const handleObjectMoving = useCallback((options: fabric.IEvent<MouseEvent>) => {
    if (!canvas) return;
    
    // First, clear any guides from the previous move event
    guideLines.forEach(line => canvas.remove(line));
    guideLines = [];

    const movingObject = options.target!;
    movingObject.setCoords();

    // Use getCoords() for precise corner coordinates (tl, tr, bl, br)
    const movingCoords = movingObject.getCoords();
    const objectEdges = {
        top: movingCoords[0].y,
        left: movingCoords[0].x,
        bottom: movingCoords[2].y,
        right: movingCoords[1].x,
        vCenter: movingCoords[0].y + movingObject.getScaledHeight() / 2,
        hCenter: movingCoords[0].x + movingObject.getScaledWidth() / 2,
    };
    
    let snapX: number | null = null;
    let snapY: number | null = null;
    let deltaX = 0;
    let deltaY = 0;
    const newGuideLines: fabric.Line[] = [];

    const canvasEdges = {
      left: 0,
      hCenter: canvas.getWidth() / 2,
      right: canvas.getWidth(),
      top: 0,
      vCenter: canvas.getHeight() / 2,
      bottom: canvas.getHeight(),
    };

    const objects = canvas.getObjects().filter(obj => obj !== movingObject && obj.visible && !obj.data?.isGuide);

    const checkSnap = (movingEdge: number, staticEdge: number, alignment: 'v' | 'h') => {
        if (Math.abs(movingEdge - staticEdge) < SNAPPING_THRESHOLD) {
            if (alignment === 'v') { // Vertical alignment, horizontal line
                deltaY = staticEdge - movingEdge;
                snapY = movingObject.top! + deltaY;
                const line = new fabric.Line([0, staticEdge, canvas.getWidth(), staticEdge], { stroke: '#4f46e5', strokeWidth: 1, data: {isGuide: true}, selectable: false, evented: false });
                newGuideLines.push(line);
            } else { // Horizontal alignment, vertical line
                deltaX = staticEdge - movingEdge;
                snapX = movingObject.left! + deltaX;
                const line = new fabric.Line([staticEdge, 0, staticEdge, canvas.getHeight()], { stroke: '#4f46e5', strokeWidth: 1, data: {isGuide: true}, selectable: false, evented: false });
                newGuideLines.push(line);
            }
        }
    };
    
    // --- Alignment with other Objects ---
    objects.forEach(staticObject => {
        staticObject.setCoords();
        const staticCoords = staticObject.getCoords();
        const staticEdges = {
            top: staticCoords[0].y,
            left: staticCoords[0].x,
            bottom: staticCoords[2].y,
            right: staticCoords[1].x,
            vCenter: staticCoords[0].y + staticObject.getScaledHeight() / 2,
            hCenter: staticCoords[0].x + staticObject.getScaledWidth() / 2,
        };

        // Horizontal (Y-axis) snapping
        checkSnap(objectEdges.top, staticEdges.top, 'v');
        checkSnap(objectEdges.bottom, staticEdges.bottom, 'v');
        checkSnap(objectEdges.vCenter, staticEdges.vCenter, 'v');
        checkSnap(objectEdges.top, staticEdges.bottom, 'v');
        checkSnap(objectEdges.bottom, staticEdges.top, 'v');

        // Vertical (X-axis) snapping
        checkSnap(objectEdges.left, staticEdges.left, 'h');
        checkSnap(objectEdges.right, staticEdges.right, 'h');
        checkSnap(objectEdges.hCenter, staticEdges.hCenter, 'h');
        checkSnap(objectEdges.left, staticEdges.right, 'h');
        checkSnap(objectEdges.right, staticEdges.left, 'h');
    });

    // --- Alignment with Canvas ---
    checkSnap(objectEdges.left, canvasEdges.left, 'h');
    checkSnap(objectEdges.right, canvasEdges.right, 'h');
    checkSnap(objectEdges.hCenter, canvasEdges.hCenter, 'h');
    checkSnap(objectEdges.top, canvasEdges.top, 'v');
    checkSnap(objectEdges.bottom, canvasEdges.bottom, 'v');
    checkSnap(objectEdges.vCenter, canvasEdges.vCenter, 'v');
    
    // --- Equal Spacing ---
    const sortedObjects = objects.sort((a,b) => a.getCoords()[0].x - b.getCoords()[0].x);
    const movingRect = {left: objectEdges.left, width: objectEdges.right - objectEdges.left};

    for(let i = 0; i < sortedObjects.length - 1; i++) {
      const obj1Coords = sortedObjects[i].getCoords();
      const obj2Coords = sortedObjects[i+1].getCoords();
      const obj1 = { left: obj1Coords[0].x, width: obj1Coords[1].x - obj1Coords[0].x };
      const obj2 = { left: obj2Coords[0].x };

      const space = obj2.left - (obj1.left + obj1.width);
      if (space <= 0) continue; // Ignore overlapping objects

      // Check space between obj1 and moving object
      const spaceToMoving1 = movingRect.left - (obj1.left + obj1.width);
      if(Math.abs(spaceToMoving1 - space) < SNAPPING_THRESHOLD) {
          deltaX = space - spaceToMoving1;
          snapX = movingObject.left! + deltaX;
      }

      // Check space between moving object and obj2
      const spaceToMoving2 = obj2.left - (movingRect.left + movingRect.width);
      if(Math.abs(spaceToMoving2 - space) < SNAPPING_THRESHOLD) {
          deltaX = spaceToMoving2 - space;
          snapX = movingObject.left! + deltaX;
      }
    }


    if (snapX !== null) movingObject.set({ left: snapX });
    if (snapY !== null) movingObject.set({ top: snapY });
    
    // Add new guides to canvas and internal tracker
    newGuideLines.forEach(line => {
      canvas.add(line);
      line.bringToFront();
      guideLines.push(line);
    });

  }, [canvas]); 
  
  useEffect(() => {
    if (!canvas) return;
    
    canvas.on('object:moving', handleObjectMoving);
    canvas.on('mouse:up', clearGuides);
    canvas.on('selection:cleared', clearGuides);


    return () => {
      if (canvas) {
        canvas.off('object:moving', handleObjectMoving);
        canvas.off('mouse:up', clearGuides);
        canvas.off('selection:cleared', clearGuides);
      }
    }
  }, [canvas, handleObjectMoving, clearGuides]);
}

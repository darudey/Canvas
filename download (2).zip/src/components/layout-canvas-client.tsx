
"use client";

import {
  useState, useRef, useEffect, useCallback, type ChangeEvent,
} from "react";
import { fabric } from "fabric";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogClose, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  ImageUp, Palette, Trash2, Download, Loader2, SendToBack, BringToFront, LayoutTemplate, PlusSquare, RectangleHorizontal, Settings, Crop, Eye, EyeOff, Space, Undo2, Redo2,
} from "lucide-react";
import { detectLayoutStructure } from "@/ai/flows/detect-layout-structure";
import { useToast } from "@/hooks/use-toast";
import { FloatingCropBar } from "@/components/ui/floating-crop-bar";
import { useCanvasHistory } from "@/hooks/use-canvas-history";
import { BorderStyleIcon } from "@/components/icons/border-style-icon";
import { BorderEditor } from "@/components/border-editor";

/* ---------- TYPES ---------- */
type CanvasSize = { width: number; height: number };
type CanvasSizeMap = Record<string, CanvasSize>;
type BorderProps = {
  color: string;
  width: number;
  dashed: boolean;
  radius: number;
}

/* ---------- CONSTANTS ---------- */
const INITIAL_SIZES: CanvasSizeMap = { "400x600": { width: 400, height: 600 } };
const SNAPPING_THRESHOLD = 8;


/* ---------- COMPONENT ---------- */
export default function LayoutCanvasClient() {
  /* ---------- Refs ---------- */
  const canvasEl          = useRef<HTMLCanvasElement>(null);
  const fabricCanvas      = useRef<fabric.Canvas | null>(null);
  const canvasWrapper     = useRef<HTMLDivElement>(null);
  const imageInput        = useRef<HTMLInputElement>(null);
  const templateInput     = useRef<HTMLInputElement>(null);

  /* ---------- State ---------- */
  const { toast } = useToast();
  const [bgColor, setBgColor]             = useState("#F8F8FF");
  const [aiLoading, setAiLoading]         = useState(false);
  const [sizes, setSizes]                 = useState<CanvasSizeMap>(INITIAL_SIZES);
  const [sizeKey, setSizeKey]             = useState<keyof CanvasSizeMap>("400x600");
  const [editSizesOpen, setEditSizesOpen] = useState(false);
  const [sizePopoverOpen, setSizePopoverOpen] = useState(false);
  const [tempSizes, setTempSizes]         = useState(sizes);
  const [newSize, setNewSize]             = useState({ width: "", height: "" });
  const [activeObject, setActiveObject]   = useState<fabric.Object | null>(null);
  const [activeSelectionCount, setActiveSelectionCount] = useState(0);
  const [hiddenObjectCount, setHiddenObjectCount] = useState(0);

  const [cropState, setCropState]         = useState<{
    group: fabric.Group;
    image: fabric.Image;
    overlay: fabric.Rect;
  } | null>(null);
  const [cropBtnPos, setCropBtnPos]       = useState<{ top: number; left: number } | null>(null);
  
  const [borderProps, setBorderProps] = useState<BorderProps>({
    color: '#000000',
    width: 2,
    dashed: false,
    radius: 0,
  });
  const [borderPopoverOpen, setBorderPopoverOpen] = useState(false);
  
  // Custom Hooks
  const { 
    updateHistory, 
    handleUndo, 
    handleRedo, 
    canUndo, 
    canRedo,
    isRestoringHistory
  } = useCanvasHistory(fabricCanvas.current);

  const updateCropBtnPos = useCallback(() => {
    const canvas = fabricCanvas.current;
    if (!canvas || !canvas.getActiveObject() || canvas.getActiveObject()?.type !== 'group') {
      setCropBtnPos(null);
      return;
    }
  
    const active = canvas.getActiveObject() as fabric.Group;
    if (active?.data?.isCropGroup) {
      const { tr } = active.oCoords!;
      const { top, left } = canvas.getElement().getBoundingClientRect();
      setCropBtnPos({
        top : tr.y + top + window.scrollY - 14,
        left: tr.x + left + window.scrollX - 14,
      });
    } else {
      setCropBtnPos(null);
    }
  }, []);

  const checkHiddenObjects = useCallback(() => {
    const canvas = fabricCanvas.current;
    if (!canvas) return;
    const hiddenCount = canvas.getObjects().filter(obj => !obj.visible && !obj.data?.isGuide).length;
    setHiddenObjectCount(hiddenCount);
  }, []);
  
  const updateActiveSelection = useCallback(() => {
      const canvas = fabricCanvas.current;
      if (!canvas) return;
      const active = canvas.getActiveObject();
      setActiveObject(active);

      if (active?.type === 'activeSelection') {
        const selection = active as fabric.ActiveSelection;
        setActiveSelectionCount(selection.size());
        const firstObj = selection.getObjects()[0] as fabric.Group;
        const frame = firstObj?.getObjects('rect')[0] as fabric.Rect;
        if (frame) {
            setBorderProps({
                color: frame.stroke || '#000000',
                width: frame.strokeWidth || 2,
                dashed: !!frame.strokeDashArray,
                radius: frame.rx || 0,
            });
        }
      } else if (active && active.type === 'group') {
        setActiveSelectionCount(1);
        const frame = (active as fabric.Group).getObjects('rect')[0] as fabric.Rect;
         if (frame) {
            setBorderProps({
                color: frame.stroke || '#000000',
                width: frame.strokeWidth || 2,
                dashed: !!frame.strokeDashArray,
                radius: frame.rx || 0,
            });
        }
      } else {
        setActiveSelectionCount(0);
      }
      updateCropBtnPos();
  }, [updateCropBtnPos]);

  const onObjectModified = useCallback((e: fabric.IEvent) => {
    if (isRestoringHistory.current) return;
    updateHistory();
    updateCropBtnPos();
  
    const g = e.target as fabric.Group;
    if (!g?.data?.isCropGroup) return;

    const img   = g.getObjects("image")[0] as fabric.Image;
    const frame = g.getObjects("rect")[0] as fabric.Rect;
    
    if (!img || !frame) return;

    // Prevent image from scaling with the group
    img.set({
      scaleX: img.scaleX! / g.scaleX!,
      scaleY: img.scaleY! / g.scaleY!,
    });
    g.clipPath = frame; // Re-apply clipPath
    g.addWithUpdate(); // Force redraw
  }, [updateCropBtnPos, updateHistory, isRestoringHistory]);

  const handleObjectMoving = useCallback((options: fabric.IEvent<MouseEvent>) => {
    updateCropBtnPos();
    
    const canvas = fabricCanvas.current;
    if (!canvas) return;
    
    let guideLines: fabric.Line[] = [];

    const clearGuides = () => {
        canvas.getObjects('line').forEach(obj => {
          if (obj.data?.isGuide) canvas.remove(obj);
        });
        canvas.renderAll();
    };
    
    clearGuides();

    const movingObject = options.target!;
    movingObject.setCoords();

    const movingCoords = movingObject.getCoords();
    const objectEdges = {
        top: movingCoords[0].y,
        left: movingCoords[0].x,
        bottom: movingCoords[2].y,
        right: movingCoords[1].x,
        vCenter: movingCoords[0].y + movingObject.getScaledHeight() / 2,
        hCenter: movingCoords[0].x + movingObject.getScaledWidth() / 2,
    };
    
    let snapX: number | null = null;
    let snapY: number | null = null;
    const newGuideLines: fabric.Line[] = [];

    const canvasEdges = {
      left: 0,
      hCenter: canvas.getWidth() / 2,
      right: canvas.getWidth(),
      top: 0,
      vCenter: canvas.getHeight() / 2,
      bottom: canvas.getHeight(),
    };

    const objects = canvas.getObjects().filter(obj => obj !== movingObject && obj.visible && !obj.data?.isGuide);

    const checkSnap = (movingEdge: number, staticEdge: number, alignment: 'v' | 'h') => {
        if (Math.abs(movingEdge - staticEdge) < SNAPPING_THRESHOLD) {
            if (alignment === 'v') {
                const deltaY = staticEdge - movingEdge;
                snapY = movingObject.top! + deltaY;
                const line = new fabric.Line([0, staticEdge, canvas.getWidth(), staticEdge], { stroke: '#4f46e5', strokeWidth: 1, data: {isGuide: true}, selectable: false, evented: false });
                newGuideLines.push(line);
            } else {
                const deltaX = staticEdge - movingEdge;
                snapX = movingObject.left! + deltaX;
                const line = new fabric.Line([staticEdge, 0, staticEdge, canvas.getHeight()], { stroke: '#4f46e5', strokeWidth: 1, data: {isGuide: true}, selectable: false, evented: false });
                newGuideLines.push(line);
            }
        }
    };
    
    objects.forEach(staticObject => {
        staticObject.setCoords();
        const staticCoords = staticObject.getCoords();
        const staticEdges = {
            top: staticCoords[0].y,
            left: staticCoords[0].x,
            bottom: staticCoords[2].y,
            right: staticCoords[1].x,
            vCenter: staticCoords[0].y + staticObject.getScaledHeight() / 2,
            hCenter: staticCoords[0].x + staticObject.getScaledWidth() / 2,
        };

        checkSnap(objectEdges.top, staticEdges.top, 'v');
        checkSnap(objectEdges.bottom, staticEdges.bottom, 'v');
        checkSnap(objectEdges.vCenter, staticEdges.vCenter, 'v');
        checkSnap(objectEdges.top, staticEdges.bottom, 'v');
        checkSnap(objectEdges.bottom, staticEdges.top, 'v');
        checkSnap(objectEdges.left, staticEdges.left, 'h');
        checkSnap(objectEdges.right, staticEdges.right, 'h');
        checkSnap(objectEdges.hCenter, staticEdges.hCenter, 'h');
        checkSnap(objectEdges.left, staticEdges.right, 'h');
        checkSnap(objectEdges.right, staticEdges.left, 'h');
    });

    checkSnap(objectEdges.left, canvasEdges.left, 'h');
    checkSnap(objectEdges.right, canvasEdges.right, 'h');
    checkSnap(objectEdges.hCenter, canvasEdges.hCenter, 'h');
    checkSnap(objectEdges.top, canvasEdges.top, 'v');
    checkSnap(objectEdges.bottom, canvasEdges.bottom, 'v');
    checkSnap(objectEdges.vCenter, canvasEdges.vCenter, 'v');
    
    if (snapX !== null) movingObject.set({ left: snapX });
    if (snapY !== null) movingObject.set({ top: snapY });
    
    newGuideLines.forEach(line => {
      canvas.add(line);
      line.sendToBack();
    });

    guideLines = newGuideLines;
    
    // This is the key change: use canvas.once for a reliable mouseup listener
    // that fires the 'modified' event to trigger a history save.
    const onMouseUp = () => {
      clearGuides();
      movingObject.fire('modified');
      // No need to call canvas.off since we used .once()
    };
    
    // Attach mouseup to fire modified event once at the end of the move
    canvas.once('mouse:up', onMouseUp);
    
  }, [updateCropBtnPos]);

  const onObjectAddedOrRemoved = useCallback(() => {
    checkHiddenObjects();
    if (isRestoringHistory.current) return;
    updateHistory();
  }, [checkHiddenObjects, updateHistory, isRestoringHistory]);

  const fitCanvasToContainer = useCallback(() => {
    const canvas = fabricCanvas.current;
    const wrapper = canvasWrapper.current;
    if (!canvas || !wrapper) return;
  
    const { clientWidth: containerWidth, clientHeight: containerHeight } = wrapper;
    const canvasLogicalWidth = canvas.getWidth();
    const canvasLogicalHeight = canvas.getHeight();
  
    const scaleX = containerWidth / canvasLogicalWidth;
    const scaleY = containerHeight / canvasLogicalHeight;
    const scale = Math.min(scaleX, scaleY) * 0.9;
  
    canvas.setDimensions({
      width: canvasLogicalWidth * scale,
      height: canvasLogicalHeight * scale,
    });
  
    canvas.setZoom(scale);
    canvas.renderAll();
  }, []);
  
  // Effect for initial canvas setup
  useEffect(() => {
    if (fabricCanvas.current) return; // Initialize only once

    const canvas = new fabric.Canvas(canvasEl.current, {
      selection: true,
      controlsAboveOverlay: true,
      preserveObjectStacking: true,
    });
    fabricCanvas.current = canvas;

    canvas.on({
      "selection:created" : updateActiveSelection,
      "selection:updated" : updateActiveSelection,
      "selection:cleared" : updateActiveSelection,
      "object:modified"   : onObjectModified,
      "object:moving"     : handleObjectMoving,
      "object:rotating"   : updateCropBtnPos,
      "object:scaling"    : updateCropBtnPos,
      'object:added'      : onObjectAddedOrRemoved,
      'object:removed'    : onObjectAddedOrRemoved,
    });

    const ro = new ResizeObserver(fitCanvasToContainer);
    if(canvasWrapper.current) {
      ro.observe(canvasWrapper.current);
    }

    // Set initial size
    const initialSize = sizes[sizeKey];
    canvas.setWidth(initialSize.width);
    canvas.setHeight(initialSize.height);
    fitCanvasToContainer();
    // Do not call updateHistory here, the hook handles the initial save.


    return () => {
      ro.disconnect();
      if(fabricCanvas.current) {
        // Detach all event listeners
        fabricCanvas.current.off();
        fabricCanvas.current.dispose();
        fabricCanvas.current = null;
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Effect for handling size and background color changes
  useEffect(() => {
    const canvas = fabricCanvas.current;
    if (!canvas) return;

    const logicalSize = sizes[sizeKey];
    canvas.setWidth(logicalSize.width);
    canvas.setHeight(logicalSize.height);
    
    if (canvas.backgroundColor?.toString() !== bgColor) {
      canvas.backgroundColor = bgColor;
      updateHistory();
    }
    
    fitCanvasToContainer();
    canvas.renderAll();

  }, [sizes, sizeKey, bgColor, fitCanvasToContainer, updateHistory]);

  useEffect(() => {
    if (isRestoringHistory.current) return;
    updateActiveSelection();
  }, [activeObject, isRestoringHistory, updateActiveSelection]);

  /* ---------- Crop helpers ---------- */
  const openCrop = useCallback((group: fabric.Group) => {
    if (cropState) return;
    const canvas = fabricCanvas.current;
    if (!canvas) {
      toast({ title: "Canvas not available", variant: "destructive" });
      return;
    }
  
    const imgObj = group.getObjects("image")[0] as fabric.Image;
    if (!imgObj || (imgObj as any).isPlaceholder) {
      toast({ title: "No image to crop", variant: "destructive" });
      return;
    }
  
    const overlay = new fabric.Rect({
      left: 0, top: 0,
      width: canvas.getWidth() / canvas.getZoom(), 
      height: canvas.getHeight() / canvas.getZoom(),
      fill: "rgba(0,0,0,0.55)",
      selectable: false, evented: false,
    });
  
    imgObj.clone((clone: fabric.Image) => {
      if (!clone) {
        toast({ title: "Image cloning failed", description: "Could not enter crop mode.", variant: "destructive" });
        return;
      }
      
      const groupRect = group.getBoundingRect();
      const clipRect = new fabric.Rect({
        left: groupRect.left,
        top: groupRect.top,
        width: groupRect.width,
        height: groupRect.height,
        absolutePositioned: true,
        inverted: true,
      });
      overlay.clipPath = clipRect;
  
      // Start the cloned image centered in the frame
      const centerPoint = group.getCenterPoint();
      
      clone.set({
        left: centerPoint.x,
        top: centerPoint.y,
        angle: imgObj.angle,
        scaleX: imgObj.scaleX,
        scaleY: imgObj.scaleY,
        originX: 'center',
        originY: 'center',
        lockMovementX: false, lockMovementY: false,
        lockScalingX: false, lockScalingY: false,
        lockRotation: false, selectable: true, evented: true, hasControls: true,
      });
  
      group.set({ visible: false });
      canvas.discardActiveObject();
      canvas.add(overlay, clone);
      clone.bringToFront();
      canvas.setActiveObject(clone);
  
      const onWheel = (opt: fabric.IEvent<WheelEvent>) => {
        opt.e.preventDefault(); opt.e.stopPropagation();
        
        const pointer = canvas.getPointer(opt.e);
        const zoom = (clone.scaleX || 1) * 0.999 ** opt.e.deltaY;
        
        clone.zoomToPoint(new fabric.Point(pointer.x, pointer.y), zoom);
        canvas.requestRenderAll();
      };
      canvas.on("mouse:wheel", onWheel);
  
      setCropState({ group, image: clone, overlay });
      canvas.requestRenderAll();
    });
  }, [toast, cropState]);
  
  const cancelCrop = useCallback(() => {
    const canvas = fabricCanvas.current;
    if (!cropState || !canvas) return;
    const { image, overlay, group } = cropState;
  
    canvas.off("mouse:wheel");
    canvas.remove(image, overlay);
    group.visible = true;
  
    // Explicitly turn off mouse:wheel after cancel
    if (canvas) {
      // Use canvas.off() without arguments to remove all mouse:wheel listeners
      canvas.off("mouse:wheel");
    }

    setCropState(null);
    canvas.setActiveObject(group).requestRenderAll();
  }, [cropState]);

  const confirmCrop = useCallback(() => {
    const canvas = fabricCanvas.current;
    if (!cropState || !canvas) {
      toast({ title: 'Error', description: 'Cannot confirm crop, state is invalid.', variant: 'destructive' });
      return;
    }
  
    const { group, image, overlay } = cropState;

    // Explicitly turn off mouse:wheel before removing objects
    canvas.off("mouse:wheel");


  
    const originalImg = group.getObjects("image")[0] as fabric.Image;
    if (!originalImg) {
      toast({ title: 'Error', description: 'Could not find original image to apply crop.', variant: 'destructive' });
      cancelCrop(); // Still cancel to clean up UI
      return;
    }
  
    const frame = group.getObjects("rect")[0] as fabric.Rect;
  
    const relativeTransform = fabric.util.multiplyTransformMatrices(
      fabric.util.invertTransform(group.calcTransformMatrix()),
      image.calcTransformMatrix()
    );
    const newImgPos = fabric.util.qrDecompose(relativeTransform);
  
    originalImg.set({
      scaleX: newImgPos.scaleX,
      scaleY: newImgPos.scaleY,
      angle: newImgPos.angle,
      left: newImgPos.translateX,
      top: newImgPos.translateY,
    });
  
    group.addWithUpdate();
    group.clipPath = frame;
  
    canvas.remove(image, overlay);
    group.visible = true;
  
    setCropState(null);
    canvas.setActiveObject(group).requestRenderAll();
    group.fire('modified');
  }, [cropState, cancelCrop, toast]);

  /* ---------- File / AI handlers ---------- */
  const handleTemplateFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const canvas = fabricCanvas.current;
    if (!file || !canvas) return;

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      const imageDataUri = reader.result as string;

      setAiLoading(true);
      toast({ title: "🤖 AI detecting layout..." });
      try {
        const { boxes } = await detectLayoutStructure({ imageDataUri });
        if (!boxes?.length) { toast({ title: "No layout detected", variant: "destructive" }); return; }

        const { min, max } = Math;
        const x1 = min(...boxes.map(b => b.x));
        const y1 = min(...boxes.map(b => b.y));
        const x2 = max(...boxes.map(b => b.x + b.width));
        const y2 = max(...boxes.map(b => b.y + b.height));
        const outer = { x: x1, y: y1, width: x2 - x1, height: y2 - y1 };
        
        const logicalWidth = canvas.getWidth();
        const logicalHeight = canvas.getHeight();

        const scale = Math.min(logicalWidth / outer.width, logicalHeight / outer.height) * 0.9;
        const offsetX = (logicalWidth - outer.width  * scale) / 2;
        const offsetY = (logicalHeight - outer.height * scale) / 2;

        canvas.discardActiveObject();
        boxes.forEach(b =>
          addBox(
            (b.x - outer.x) * scale + offsetX,
            (b.y - outer.y) * scale + offsetY,
            b.width  * scale,
            b.height * scale,
            false // Don't set active
          )
        );

        toast({ title: `✅ ${boxes.length} boxes created` });
      } catch {
        toast({ title: "AI failed", variant: "destructive" });
      } finally {
        setAiLoading(false);
        canvas.renderAll();
        // The object:added event will trigger history updates
      }
    };
    e.target.value = "";
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const canvas = fabricCanvas.current;
    if (!file || !canvas) return;
  
    const active = canvas.getActiveObject();
    if (active?.type !== 'group' || !active.data?.isCropGroup) {
      toast({ title: "Select a box first", variant: "destructive" });
      return;
    }
    const group = active as fabric.Group;
  
    const reader = new FileReader();
    reader.onload = (f) => {
      const data = f.target?.result as string;
      fabric.Image.fromURL(data, (img) => {
        const oldImg = group.getObjects("image")[0];
        const frame = group.getObjects("rect")[0] as fabric.Rect;
  
        if (oldImg) group.remove(oldImg);
  
        const scale = Math.max(frame.width! / img.width!, frame.height! / img.height!);
        img.set({
          name: "image",
          scaleX: scale,
          scaleY: scale,
          originX: "center",
          originY: "center",
          left: 0,
          top: 0,
          data: { isPlaceholder: false }
        });
        frame.set({
          originX: "center",
          originY: "center",
          left: 0,
          top: 0,
        });
        
        const originalLeft = group.left;
        const originalTop = group.top;
  
        group.add(img);
        img.sendToBack();
        
        group.addWithUpdate();
        
        group.set({
            left: originalLeft,
            top: originalTop,
            width: frame.width,
            height: frame.height,
        });

        group.setCoords();
        canvas.requestRenderAll();
        group.fire('modified');
      }, { crossOrigin: 'anonymous' });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  /* ---------- Box helpers ---------- */
  const addBox = (left = 0, top = 0, width = 200, height = 200, setActive = true) => {
    const canvas = fabricCanvas.current;
    if(!canvas) return;

    const frame  = new fabric.Rect({
      name : "rect",
      width, height,
      fill: "transparent",
      stroke: "#ccc", strokeWidth: 2,
      originX: "center", originY: "center",
    });

    fabric.Image.fromURL(
      `https://placehold.co/${Math.round(width)}x${Math.round(height)}.png`,
      (img) => {
        if (!fabricCanvas.current || (fabricCanvas.current as any).isDisposed) return;
        img.set({ name: "image", originX: "center", originY: "center", selectable: false, evented: false, data: { isPlaceholder: true } });
        const scale = Math.min(width / img.width!, height / img.height!);
        img.scale(scale);

        const group = new fabric.Group([frame, img], {
          left, top,
          clipPath: frame,
          data: { isCropGroup: true },
          originX: "center", originY: "center",
        });
        canvas.add(group);
        if (setActive) {
            canvas.setActiveObject(group);
        }
        canvas.requestRenderAll();
      },
      { crossOrigin: "anonymous" }
    );
  };
  
  const distributeHorizontally = () => {
    const canvas = fabricCanvas.current;
    if (!canvas) return;
    let items = canvas.getActiveObjects();
    if (items.length < 2) {
        toast({ title: "Select at least 2 objects to distribute.", variant: "destructive" });
        return;
    }

    items.sort((a, b) => a.left! - b.left!);
    const totalWidth = items.reduce((sum, item) => sum + item.getScaledWidth(), 0);
    
    let totalSpacing: number;
    let startX: number;

    if (items.length === 2) {
      const boundaries = items;
      const otherItems = canvas.getObjects().filter(o => o !== boundaries[0] && o !== boundaries[1] && o.visible && !o.data?.isGuide);
      if (otherItems.length === 0) {
        toast({title: "No other items to distribute."});
        return;
      }
      
      items = [boundaries[0], ...otherItems.sort((a, b) => a.left! - b.left!), boundaries[1]];
      
      startX = boundaries[0].left!;
      const endX = boundaries[1].left!;
      const totalSpan = endX - startX;
      const totalInnerWidth = items.slice(1, -1).reduce((sum, item) => sum + item.getScaledWidth(), 0);
      
      totalSpacing = totalSpan - boundaries[0].getScaledWidth() - totalInnerWidth;
      
    } else {
      const first = items[0];
      const last = items[items.length - 1];
      const selectionWidth = last.left! + last.getScaledWidth() - first.left!;
      totalSpacing = selectionWidth - totalWidth;
      startX = first.left!;
    }

    const spacing = totalSpacing / (items.length - 1);
    let currentX = startX;

    items.forEach((item, index) => {
        if (index > 0) {
            currentX += items[index-1].getScaledWidth() + spacing;
        }
        item.animate('left', currentX, {
            duration: 300,
            onChange: canvas.renderAll.bind(canvas),
            onComplete: () => {
                item.setCoords();
                if (index === items.length - 1) {
                    canvas.fire('object:modified', { target: canvas.getActiveObject() });
                }
            }
        });
    });
  };

  const deleteActive = () => {
    const canvas = fabricCanvas.current;
    if (!canvas) return;
    const activeObjects = canvas.getActiveObjects();
    if (!activeObjects || activeObjects.length === 0) return;

    canvas.discardActiveObject();
    activeObjects.forEach(obj => {
        canvas.remove(obj);
    });
    canvas.requestRenderAll();
  };

  const changeZ = (dir: "front" | "back") => {
    const canvas = fabricCanvas.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active) return;
  
    dir === "front" ? canvas.bringToFront(active) : canvas.sendToBack(active);
    canvas.requestRenderAll();
    active.fire('modified');
  };
  
  const hideSelected = () => {
    const canvas = fabricCanvas.current;
    if (!canvas) return;
    const activeObjects = canvas.getActiveObjects();
    if (!activeObjects || activeObjects.length === 0) return;
  
    activeObjects.forEach(obj => {
      obj.set({ visible: false });
    });
    canvas.fire('object:modified', { target: canvas.getActiveObject() });
    canvas.discardActiveObject().renderAll();
    checkHiddenObjects();
  };
  
  const unhideAll = () => {
    const canvas = fabricCanvas.current;
    if (!canvas) return;
  
    canvas.getObjects().forEach(obj => {
      if (!obj.visible && !obj.data?.isGuide) {
        obj.set({ visible: true });
      }
    });
    canvas.fire('object:modified', { target: canvas.getActiveObject() });
    canvas.renderAll();
    checkHiddenObjects();
  };
  
  const handleBorderChange = useCallback((props: Partial<BorderProps>) => {
    const canvas = fabricCanvas.current;
    const activeObjects = canvas?.getActiveObjects();
    if (!canvas || !activeObjects || activeObjects.length === 0) return;
    
    const newProps = { ...borderProps, ...props };
    setBorderProps(newProps);

    activeObjects.forEach(obj => {
      if (obj.type === 'group') {
        const frame = (obj as fabric.Group).getObjects('rect')[0] as fabric.Rect;
        if (frame) {
          frame.set({
            stroke: newProps.color,
            strokeWidth: newProps.width,
            strokeDashArray: newProps.dashed ? [10, 5] : undefined,
            rx: newProps.radius,
            ry: newProps.radius,
          });
        }
      }
    });
    canvas.requestRenderAll();
  }, [borderProps]);

  const onBorderChangeComplete = () => {
    const canvas = fabricCanvas.current;
    const activeObjects = canvas?.getActiveObjects();
    if (!canvas || !activeObjects) return;
  
    activeObjects.forEach(obj => {
      if (obj.type === 'group') {
        obj.fire('modified');
      }
    });
  };

  const exportCanvas = () => {
    const canvas = fabricCanvas.current;
    if(!canvas) return;
    if (cropState) { toast({ title: "Finish cropping first", variant: "destructive" }); return; }
    canvas.discardActiveObject().renderAll();
    
    // Temporarily set zoom to 1 for export
    const currentZoom = canvas.getZoom();
    const currentVpt = canvas.viewportTransform!.slice(0);
    
    canvas.setZoom(1);
    canvas.viewportTransform = [1, 0, 0, 1, 0, 0];
    const logicalWidth = canvas.getWidth();
    const logicalHeight = canvas.getHeight();

    canvas.setDimensions({ width: logicalWidth, height: logicalHeight });
    canvas.renderAll();

    const link = document.createElement("a");
    link.href = canvas.toDataURL({ 
        format: "png", 
        quality: 1,
    });
    link.download = "layout-canvas.png";
    link.click();
    
    // Restore zoom and viewport
    canvas.setDimensions({ width: logicalWidth * currentZoom, height: logicalHeight * currentZoom });
    canvas.setZoom(currentZoom);
    canvas.viewportTransform = currentVpt;
    canvas.renderAll();
  };

  /* ---------- Size management ---------- */
  const addSize = () => {
    const w = parseInt(newSize.width);
    const h = parseInt(newSize.height);
    if (w > 0 && h > 0) {
      const key = `${w}x${h}`;
      if (!tempSizes[key]) {
        setTempSizes({ ...tempSizes, [key]: { width: w, height: h } });
        setNewSize({ width: "", height: "" });
      } else toast({ title: "Size exists", variant: "destructive" });
    } else toast({ title: "Invalid dimensions", variant: "destructive" });
  };

  const deleteSize = (k: string) => {
    if (Object.keys(tempSizes).length === 1) {
      toast({ title: "Can't delete last size", variant: "destructive" });
      return;
    }
    const clone = { ...tempSizes };
    delete clone[k];
    setTempSizes(clone);
  };

  const saveSizes = () => {
    const newSizeKeys = Object.keys(tempSizes);
    const lastAddedKey = newSizeKeys[newSizeKeys.length - 1];
    setSizes(tempSizes);

    if (!tempSizes[sizeKey] || sizeKey !== lastAddedKey) {
      setSizeKey(lastAddedKey as keyof CanvasSizeMap);
    }
    setEditSizesOpen(false);
  };

  /* ---------- Render ---------- */
  return (
    <div className="flex flex-col h-full bg-muted/10 text-foreground">
      <div className="flex flex-col flex-1 overflow-hidden">
        <main ref={canvasWrapper} className="flex-1 p-4 bg-muted/40 flex items-center justify-center relative overflow-hidden">
          <canvas ref={canvasEl} className="shadow-2xl" style={{ boxShadow: "0 25px 50px -12px rgba(0,0,0,.4)" }} />
          {cropState && <FloatingCropBar onDone={confirmCrop} onCancel={cancelCrop} />}
          {cropBtnPos && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="default"
                    size="icon"
                    className="absolute z-10 w-7 h-7 rounded-full shadow-lg"
                    style={{ ...cropBtnPos }}
                    onClick={() => {
                        const activeObject = fabricCanvas.current?.getActiveObject();
                        if (activeObject) {
                            openCrop(activeObject as fabric.Group)
                        }
                    }}
                  >
                    <Crop className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent><p>Crop Image</p></TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </main>

        <TooltipProvider>
          <aside className="p-2 border-t bg-background">
            <ScrollArea className="w-full whitespace-nowrap">
              <div className="flex justify-center items-center space-x-2 pb-2">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" disabled={aiLoading} onClick={() => templateInput.current?.click()}>
                      {aiLoading ? <Loader2 className="animate-spin" /> : <LayoutTemplate />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Detect Layout</TooltipContent>
                </Tooltip>
                <input ref={templateInput} type="file" accept="image/*" className="hidden" onChange={handleTemplateFile} />

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={() => addBox(50, 50)}><PlusSquare /></Button>
                  </TooltipTrigger>
                  <TooltipContent>Add Box</TooltipContent>
                </Tooltip>
                
                <BorderEditor
                    borderProps={borderProps}
                    onBorderChange={handleBorderChange}
                    onFinalChange={onBorderChangeComplete}
                    disabled={activeSelectionCount === 0}
                    isOpen={borderPopoverOpen}
                    onOpenChange={setBorderPopoverOpen}
                 />

                <div className="flex-grow" />

                <Popover open={sizePopoverOpen} onOpenChange={setSizePopoverOpen}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon"><RectangleHorizontal /></Button>
                      </PopoverTrigger>
                    </TooltipTrigger>
                    <TooltipContent>Canvas Size</TooltipContent>
                  </Tooltip>
                  <PopoverContent className="w-auto p-4">
                    <div className="grid gap-2">
                      <p className="text-sm font-medium text-center">Select canvas size</p>
                      <div className="flex items-center gap-2">
                        <Select value={sizeKey} onValueChange={v => { setSizeKey(v as keyof CanvasSizeMap); setSizePopoverOpen(false); }}>
                          <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {Object.keys(sizes).map(k => <SelectItem key={k} value={k}>{k}</SelectItem>)}
                          </SelectContent>
                        </Select>
                        <Button variant="ghost" size="icon" onClick={() => { setTempSizes(sizes); setEditSizesOpen(true); }}>
                          <Settings className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>

                <Tooltip>
                  <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" onClick={() => {
                          const colorPicker = document.createElement('input');
                          colorPicker.type = 'color';
                          colorPicker.value = bgColor;
                          colorPicker.addEventListener('change', (e) => {
                            setBgColor((e.target as HTMLInputElement).value);
                          });
                          colorPicker.click();
                      }}>
                          <Palette />
                      </Button>
                  </TooltipTrigger>
                  <TooltipContent>Canvas Background</TooltipContent>
              </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" disabled={aiLoading || !!cropState} onClick={() => imageInput.current?.click()}>
                      <ImageUp />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Upload Image to Box</TooltipContent>
                </Tooltip>
                <input ref={imageInput} type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" disabled={!canUndo} onClick={handleUndo}><Undo2 /></Button>
                  </TooltipTrigger>
                  <TooltipContent>Undo</TooltipContent>
                </Tooltip>
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" disabled={!canRedo} onClick={handleRedo}><Redo2 /></Button>
                  </TooltipTrigger>
                  <TooltipContent>Redo</TooltipContent>
                </Tooltip>

                <div className="border-l h-8 mx-2" />
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" disabled={activeSelectionCount < 2} onClick={distributeHorizontally}><Space /></Button>
                  </TooltipTrigger>
                  <TooltipContent>Distribute Horizontally</TooltipContent>
                </Tooltip>

                <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" disabled={!activeObject} onClick={() => changeZ("front")}><BringToFront /></Button></TooltipTrigger><TooltipContent>Bring Front</TooltipContent></Tooltip>
                <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" disabled={!activeObject} onClick={() => changeZ("back")}><SendToBack /></Button></TooltipTrigger><TooltipContent>Send Back</TooltipContent></Tooltip>
                
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" disabled={!activeObject} onClick={hideSelected}><EyeOff /></Button>
                  </TooltipTrigger>
                  <TooltipContent>Hide Selected</TooltipContent>
                </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="relative">
                      <Button variant="ghost" size="icon" disabled={hiddenObjectCount === 0} onClick={unhideAll}>
                          <Eye />
                      </Button>
                      {hiddenObjectCount > 0 && (
                          <span className="absolute top-0 right-0 inline-flex items-center justify-center w-4 h-4 text-xs font-bold leading-none text-white bg-primary rounded-full transform translate-x-1/4 -translate-y-1/4">
                              {hiddenObjectCount}
                          </span>
                      )}
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>Unhide All</TooltipContent>
                </Tooltip>

                <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" disabled={!activeObject} onClick={deleteActive}><Trash2 /></Button></TooltipTrigger><TooltipContent>Delete Box</TooltipContent></Tooltip>

                <div className="border-l h-8 mx-2" />

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={exportCanvas}><Download /></Button>
                  </TooltipTrigger>
                  <TooltipContent>Export PNG</TooltipContent>
                </Tooltip>
              </div>
              <ScrollBar orientation="horizontal" className="hidden" />
            </ScrollArea>
          </aside>
        </TooltipProvider>
      </div>
      <Dialog open={editSizesOpen} onOpenChange={setEditSizesOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Canvas Sizes</DialogTitle></DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex flex-col gap-2 max-h-60 overflow-y-auto pr-2">
              {Object.keys(tempSizes).map(k => (
                <div key={k} className="flex items-center gap-2">
                  <Input readOnly value={k} className="flex-1" />
                  <Button variant="ghost" size="icon" onClick={() => deleteSize(k)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            <div className="flex items-end gap-2 border-t pt-4">
              <div className="grid gap-1.5">
                <Label htmlFor="width">Width</Label>
                <Input id="width" type="number" placeholder="e.g. 1920" value={newSize.width} onChange={e => setNewSize({...newSize, width: e.target.value})} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="height">Height</Label>
                <Input id="height" type="number" placeholder="e.g. 1080" value={newSize.height} onChange={e => setNewSize({...newSize, height: e.target.value})} />
              </div>
              <Button onClick={addSize}>Add New Size</Button>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button onClick={saveSizes}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

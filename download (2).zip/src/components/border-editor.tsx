
"use client";

import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { BorderStyleIcon } from "@/components/icons/border-style-icon";

type BorderProps = {
  color: string;
  width: number;
  dashed: boolean;
  radius: number;
}

type BorderEditorProps = {
  borderProps: BorderProps;
  onBorderChange: (props: Partial<BorderProps>) => void;
  onFinalChange: () => void;
  disabled: boolean;
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
}

export function BorderEditor({
  borderProps,
  onBorderChange,
  onFinalChange,
  disabled,
  isOpen,
  onOpenChange,
}: BorderEditorProps) {
  return (
    <Popover open={isOpen} onOpenChange={(open) => {
        if(!open) onFinalChange();
        onOpenChange(open);
    }}>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" disabled={disabled}>
                <BorderStyleIcon />
              </Button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent>Border Styles</TooltipContent>
        </Tooltip>
      </TooltipProvider>
      <PopoverContent className="w-64">
        <div className="grid gap-4">
          <div className="space-y-2">
            <h4 className="font-medium leading-none">Border</h4>
            <p className="text-sm text-muted-foreground">
              Customize the look of your frames.
            </p>
          </div>
          <div className="grid gap-y-4">
            <div className="flex items-center justify-between">
              <Label>Color</Label>
              <input
                type="color"
                value={borderProps.color}
                className="w-8 h-8 p-0 border-none bg-transparent rounded cursor-pointer"
                onChange={(e) => {
                    onBorderChange({ color: e.target.value });
                }}
                onBlur={onFinalChange}
              />
            </div>
            <div className="grid gap-2">
              <Label>Width ({borderProps.width}px)</Label>
              <Slider
                value={[borderProps.width]}
                onValueChange={(val) => onBorderChange({ width: val[0] })}
                onValueCommit={onFinalChange}
                max={50}
                step={1}
              />
            </div>
            <div className="grid gap-2">
              <Label>Radius ({borderProps.radius}px)</Label>
              <Slider
                value={[borderProps.radius]}
                onValueChange={(val) => onBorderChange({ radius: val[0] })}
                onValueCommit={onFinalChange}
                max={100}
                step={1}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Dashed</Label>
              <Switch
                checked={borderProps.dashed}
                onCheckedChange={(checked) => {
                    onBorderChange({ dashed: checked });
                    onFinalChange();
                }}
              />
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
